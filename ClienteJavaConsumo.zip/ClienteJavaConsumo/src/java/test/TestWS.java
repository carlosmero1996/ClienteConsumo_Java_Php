/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import ws.WSoperaciones_Service;
import ws.WSoperaciones;

/**
 *
 * @author carlos
 */
public class TestWS {

    public static void main(String[] args) {
        
        WSoperaciones_Service servicio=new WSoperaciones_Service();
        WSoperaciones cliente=servicio.getWSoperacionesPort();
        
        if(cliente.login("carlos", "123456")){
            System.out.println("credenciales correctas");
        }else{
            System.out.println("credenciales incorrectas");
        }
        
        if(cliente.procesarPago(40, 400000)!=-1){
             System.out.println("pago realizado con exito");
             System.out.println("su vuelto es "+cliente.procesarPago(40, 400000));
        }else{
            System.out.println("saldo insuficiente");
       }
       
    }
    
}
